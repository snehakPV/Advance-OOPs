using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question3
{
    public class DrawPyramid:Draw
    {
        public override void DrawLine()
        {
            System.Console.WriteLine("Drawing Pyramid");
        }
    }
}