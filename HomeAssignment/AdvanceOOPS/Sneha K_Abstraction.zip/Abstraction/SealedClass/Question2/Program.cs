﻿using System;
namespace Question2;
class Program
{
    public static void Main(string[] args)
    {
       PatientInfo patient=new PatientInfo();
       DoctorInfo doctor=new DoctorInfo(); 
    }
}