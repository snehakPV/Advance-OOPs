using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question2
{
    public class Calculator
    {
       public abstract double area (double [] dimensions);
       public abstract double volume(double [] dimensions); 
    }
}