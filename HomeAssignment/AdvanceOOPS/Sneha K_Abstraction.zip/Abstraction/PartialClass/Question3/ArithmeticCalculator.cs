using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question3
{
    public partial class Calculator
    {
        public int Addition(int num1,int num2)
        {
            return num1+num2;
        }
        public int Subtraction(int num1,int num2)
        {
            return num1-num2;
        }
    }
}