using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question3
{
    public partial class Calculator
    {
        public double Sin(double num)
        {
            return Math.Sin(num);
        }
        public double Cos(double num)
        {
            return Math.Cos(num);
        }
        public double Tan(double num)
        {
            return Math.Tan(num);
        }
    }
}