using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question3
{
    public interface ITransaction
    {
        decimal TotalAmount {get;}
        void CalculateAmount();
        void DisplayBill();
    }
}