﻿using System;
using System.Collections.Generic;
namespace Question4;
class Program
{
    
    public static void Main(string[] args)
    {
        List<Attendance> attendance=new List<Attendance>();
    }
}
