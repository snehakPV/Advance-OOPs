using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question4
{
    public class Attendance
    {
        public DateTime Date {get;set;}
        public double NumberOfHoursWorked {get;set;}
        /*public Attendance(DateTime date,int numberOfHoursWorked)
        {
            Date=date;
            NumberOfHoursWorked=numberOfHoursWorked;
        }*/
    }
    
}