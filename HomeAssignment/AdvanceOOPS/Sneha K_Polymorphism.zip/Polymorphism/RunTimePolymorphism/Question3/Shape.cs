using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question3
{
    public abstract class Shape
    {
        public abstract double DrawShape();
    }
}