using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Question3
{
    public class Rectangle:Shape
    {
        public override double DrawShape()
        {
            System.Console.WriteLine("Drawing a Rectangle");
            return 0;
        }
    }
}