﻿using System;
namespace Question1;
class Program
{
    public static void Main(string[] args)
    {
        EEE eee=new EEE();
        CSE cse=new CSE();
        eee.BookInfo();
        eee.DisplayInfo();
        cse.BookInfo();
        cse.DisplayInfo();
    }
}
